This is the project submition of 	Simon Kindstroem student# 2016-82282 
					Simeon Varbanov student# 2017-28499
Structure:
- Project
	- Implementation
		- Dynamic-Perfect-Hashing.py
		- Tests.py
	- Report
		- Project Report.pdf
	- README.txt

* The contribution of each member can be clearly seen in the Git commit logs and also in meeting log.